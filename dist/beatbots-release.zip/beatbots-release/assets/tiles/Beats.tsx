<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Beats" tilewidth="32" tileheight="32">
 <image source="../Beats.png" width="256" height="32"/>
 <tile id="0">
  <properties>
   <property name="Color" value="0"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Color" value="5"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Color" value="1"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Color" value="2"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Color" value="3"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Color" value="4"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Color" value="6"/>
  </properties>
 </tile>
</tileset>
